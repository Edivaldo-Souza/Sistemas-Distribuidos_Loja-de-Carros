/**
 * 
 */
/**
 * @author souza
 *
 */
module praticaOffline03_SD {
	exports server;
	exports interfaces;
	requires java.rmi;
}